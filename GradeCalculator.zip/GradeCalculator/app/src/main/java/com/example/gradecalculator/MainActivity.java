package com.example.gradecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText Q = findViewById(R.id.editText1);
        final EditText H = findViewById(R.id.editText2);
        final EditText M = findViewById(R.id.editText3);
        final EditText F = findViewById(R.id.editText4);
        Button C = findViewById(R.id.button);

        final TextView result = findViewById(R.id.textView6);

        C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(Q.getText().toString());
                int b = Integer.parseInt(H.getText().toString());
                int c = Integer.parseInt(M.getText().toString());
                int d = Integer.parseInt(F.getText().toString());
                int shay = a + b + c + d;
                result.setText(shay+"");
            }
        });


    }
}